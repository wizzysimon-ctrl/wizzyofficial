-- WIZZY OFFICIAL: run this in Supabase SQL Editor.
create extension if not exists pgcrypto;

create table if not exists public.posts (
  id uuid primary key default gen_random_uuid(),
  user_id uuid not null references auth.users(id) on delete cascade,
  type text not null check (type in ('news','music','video','photo')),
  title text not null,
  body text default '',
  media_url text,
  published boolean not null default true,
  created_at timestamptz not null default now()
);

alter table public.posts enable row level security;

create policy "Public can read published posts"
on public.posts for select
using (published = true or auth.uid() = user_id);

create policy "Admins can insert own posts"
on public.posts for insert to authenticated
with check (auth.uid() = user_id);

create policy "Admins can update own posts"
on public.posts for update to authenticated
using (auth.uid() = user_id)
with check (auth.uid() = user_id);

create policy "Admins can delete own posts"
on public.posts for delete to authenticated
using (auth.uid() = user_id);

insert into storage.buckets (id, name, public)
values ('media','media',true)
on conflict (id) do nothing;

create policy "Public can view media"
on storage.objects for select
using (bucket_id = 'media');

create policy "Authenticated users can upload media"
on storage.objects for insert to authenticated
with check (bucket_id = 'media');

create policy "Authenticated users can update media"
on storage.objects for update to authenticated
using (bucket_id = 'media')
with check (bucket_id = 'media');

create policy "Authenticated users can delete media"
on storage.objects for delete to authenticated
using (bucket_id = 'media');