// Wizzy Official configuration.
// After creating your Supabase project, put the two public values below.
// NEVER put a Supabase service_role key here.
window.WIZZY_CONFIG = {
  SUPABASE_URL: "PASTE_YOUR_SUPABASE_URL_HERE",
  SUPABASE_ANON_KEY: "PASTE_YOUR_SUPABASE_ANON_KEY_HERE"
};