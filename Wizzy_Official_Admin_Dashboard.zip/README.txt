# Wizzy Official — Admin Dashboard

## Icyo iyi package ikora
- Website ya Wizzy Official
- Admin login
- News/posts
- Music upload
- YouTube videos
- Gallery photo upload
- Publish/Delete
- Supabase database + storage

## Ibyo ugomba gukora mbere yo kuyishyira kuri GitHub
1. Kora Supabase project kuri https://supabase.com/
2. Muri Supabase → SQL Editor, paste `supabase.sql` hanyuma Run.
3. Muri Authentication → Users, kora user ya admin ukoresheje email na password.
4. Muri Project Settings → API, fata `Project URL` na `anon public key`.
5. Fungura `config.js`, usimbuze:
   SUPABASE_URL
   SUPABASE_ANON_KEY
6. Upload files zose muri GitHub repository `wizzysimon-ctrl/wizzyofficial`.
7. Admin dashboard izaba kuri:
   https://wizzysimon-ctrl.github.io/wizzyofficial/admin.html

IMPORTANT:
- Ntuzigere ushyira `service_role` key muri `config.js`.
- `anon public key` ni yo ikoreshwa kuri website.
- Admin email/password ntushyire muri code.

## Uko uzajya ushyiraho post
Fungura `/admin.html`, login, hitamo type, andika title/description, shyiramo file cyangwa YouTube URL, ukande Publish.
